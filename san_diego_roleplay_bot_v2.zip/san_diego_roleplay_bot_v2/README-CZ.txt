SAN DIEGO ROLEPLAY BOT — V2 STARTER

Hlavní příkaz pro občanský průkaz:
1. Člen použije /id create.
2. Otevře se formulář, kam vyplní First Name, Last Name, Date of Birth (YYYY-MM-DD), Gender.
3. Bot automaticky vytvoří soukromý kanál v serveru San Diego Citizen Database a vloží kartu občana.

Záznamy:
- /id citation
- /id registration
- /id jail
- /id warrant
Tyto příkazy jsou omezené na administrátory nebo role uvedené v STAFF_ROLE_IDS.
Dále jsou připravené základní systémy: /balance, /daily, /transfer, /bank, /shop, /inventory, /job, /psychotest, /gunshop, /blackmarket, /postal, /locations, /roll-dice, /yes-no, /call, /mdt, /manage-job, /issue-invoice, /item-give, /ticket.

DŮLEŽITÉ OMEZENÍ:
- Toto je rozšířený startovací základ, ne finální plně otestovaný produkční bot. MDT vozidel, frakce, plné vozidlové garáže, některé ekonomické a nelegální RP systémy jsou zatím zjednodušené nebo čekají na rozšíření.
- Databáze občanů je v Discord kanálech, ale ekonomická data se ukládají do data.json. Bez trvalého úložiště hostingu se data.json může po restartu/novém nasazení ztratit.
- Občanské kanály jsou skryté před @everyone. Pro staff role nastavte oprávnění v kódu/konfiguraci; zatím do nich vidí bot a správci serveru. Doporučeno před použitím upravit oprávnění.
- Používej jen fiktivní RP údaje, ne skutečné citlivé osobní údaje.
- Nikdy nesdílej DISCORD_TOKEN.

Spuštění:
1. Node.js 20+
2. npm install
3. Zkopíruj .env.example na .env
4. Vyplň DISCORD_TOKEN, CLIENT_ID, MAIN_GUILD_ID, DATABASE_GUILD_ID
5. npm run register
6. npm start

MAIN_GUILD_ID = ID hlavního serveru San Diego Roleplay.
DATABASE_GUILD_ID = ID serveru San Diego Citizen Database.
CLIENT_ID = Application ID z Developer Portal.
DISCORD_TOKEN = token ze sekce Bot. Drž ho v tajnosti.
STAFF_ROLE_IDS = ID rolí oprávněných zapisovat RP záznamy, oddělená čárkou.
