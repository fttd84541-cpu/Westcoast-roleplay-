require("dotenv").config();
const fs = require("node:fs");
const path = require("node:path");
const {
  Client, GatewayIntentBits, ChannelType, PermissionsBitField,
  EmbedBuilder, SlashCommandBuilder, REST, Routes, ModalBuilder,
  TextInputBuilder, TextInputStyle, ActionRowBuilder
} = require("discord.js");

const required = ["DISCORD_TOKEN", "CLIENT_ID", "MAIN_GUILD_ID", "DATABASE_GUILD_ID"];
for (const key of required) {
  if (!process.env[key] || process.env[key].startsWith("PASTE_")) {
    console.error(`Missing ${key}. Set it in environment variables.`);
    process.exit(1);
  }
}
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const dataFile = path.join(__dirname, "data.json");
function loadData() {
  try { return JSON.parse(fs.readFileSync(dataFile, "utf8")); }
  catch { return { users: {}, cooldowns: {} }; }
}
function saveData(data) { fs.writeFileSync(dataFile, JSON.stringify(data, null, 2)); }
const data = loadData();
const staffRoleIds = (process.env.STAFF_ROLE_IDS || "").split(",").map(s => s.trim()).filter(Boolean);
const money = n => "$" + Number(n || 0).toLocaleString("en-US");
const clean = s => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "");
function slug(s) { return clean(s).toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").slice(0, 85) || "citizen"; }
function userData(id) {
  if (!data.users[id]) data.users[id] = { cash: 500, bank: 0, inventory: {}, job: null, vehicles: [], dailyAt: 0, psychotest: false, firearmLicense: false };
  return data.users[id];
}
function staff(interaction) {
  if (interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) return true;
  return !!interaction.member?.roles?.cache && staffRoleIds.some(id => interaction.member.roles.cache.has(id));
}
async function requireStaff(i) {
  if (staff(i)) return true;
  await i.reply({ content: "You need administrator permission or an approved staff role.", ephemeral: true });
  return false;
}
const letterCategories = [
  ["a-c", "ABCČ"], ["d-f", "DĎEÉĚF"], ["g-i", "GHI"], ["j-l", "JKLM"],
  ["m-o", "MNOŇÓ"], ["p-r", "PQRŘ"], ["s-u", "SŠTUÚŮ"], ["v-z", "VWXYZŽ"]
];
function categoryKey(last) {
  const first = clean(last).toUpperCase()[0] || "A";
  return (letterCategories.find(([, chars]) => chars.includes(first)) || ["other"])[0];
}
async function getCategory(guild, key) {
  let c = guild.channels.cache.find(x => x.type === ChannelType.GuildCategory && x.name === key);
  if (!c) c = await guild.channels.create({
    name: key, type: ChannelType.GuildCategory,
    permissionOverwrites: [
      { id: guild.roles.everyone.id, deny: [PermissionsBitField.Flags.ViewChannel] },
      { id: client.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.EmbedLinks, PermissionsBitField.Flags.ReadMessageHistory, PermissionsBitField.Flags.ManageChannels] }
    ]
  });
  return c;
}
function citizenEmbed(first, last, dob, gender, citizenId) {
  return new EmbedBuilder().setColor(0x233b5d).setTitle("SAN DIEGO CITIZEN DATABASE")
    .setDescription(`**Citizen ID:** ${citizenId}\nOfficial San Diego Roleplay citizen record`)
    .addFields(
      { name: "FIRST NAME", value: first, inline: true },
      { name: "LAST NAME", value: last, inline: true },
      { name: "DATE OF BIRTH", value: dob, inline: true },
      { name: "GENDER", value: gender, inline: true },
      { name: "CITATIONS", value: "No records.", inline: false },
      { name: "REGISTRATION", value: "No records.", inline: false },
      { name: "JAIL RECORD", value: "No records.", inline: false },
      { name: "WARRANT", value: "No records.", inline: false }
    ).setFooter({ text: "San Diego Roleplay • fictional RP records only" }).setTimestamp();
}
function cmd(name, description) { return new SlashCommandBuilder().setName(name).setDescription(description); }
const commands = [
  new SlashCommandBuilder().setName("id").setDescription("Citizen identity and database")
    .addSubcommand(s => s.setName("create").setDescription("Create a citizen ID using a form"))
    .addSubcommand(s => s.setName("view").setDescription("Find a citizen record").addStringOption(o => o.setName("name").setDescription("Citizen channel name, e.g. john-miller").setRequired(true)))
    .addSubcommand(s => s.setName("citation").setDescription("Add a citation to a citizen record")
      .addStringOption(o => o.setName("name").setDescription("Citizen channel, e.g. john-miller").setRequired(true))
      .addStringOption(o => o.setName("details").setDescription("Citation details").setRequired(true)))
    .addSubcommand(s => s.setName("registration").setDescription("Add vehicle or firearm registration")
      .addStringOption(o => o.setName("name").setDescription("Citizen channel").setRequired(true))
      .addStringOption(o => o.setName("details").setDescription("Registration details").setRequired(true)))
    .addSubcommand(s => s.setName("jail").setDescription("Add jail record")
      .addStringOption(o => o.setName("name").setDescription("Citizen channel").setRequired(true))
      .addStringOption(o => o.setName("details").setDescription("Jail record details").setRequired(true)))
    .addSubcommand(s => s.setName("warrant").setDescription("Add warrant record")
      .addStringOption(o => o.setName("name").setDescription("Citizen channel").setRequired(true))
      .addStringOption(o => o.setName("details").setDescription("Warrant details").setRequired(true))),
  cmd("balance", "View your cash and bank balance"),
  cmd("daily", "Claim your daily RP money"),
  new SlashCommandBuilder().setName("transfer").setDescription("Transfer cash to another member")
    .addUserOption(o => o.setName("member").setDescription("Recipient").setRequired(true))
    .addIntegerOption(o => o.setName("amount").setDescription("Amount in dollars").setMinValue(1).setRequired(true)),
  new SlashCommandBuilder().setName("bank").setDescription("Bank deposits and withdrawals")
    .addSubcommand(s => s.setName("deposit").setDescription("Deposit cash").addIntegerOption(o => o.setName("amount").setDescription("Amount").setMinValue(1).setRequired(true)))
    .addSubcommand(s => s.setName("withdraw").setDescription("Withdraw money").addIntegerOption(o => o.setName("amount").setDescription("Amount").setMinValue(1).setRequired(true))),
  new SlashCommandBuilder().setName("shop").setDescription("Browse or buy civilian RP items")
    .addSubcommand(s => s.setName("list").setDescription("List items"))
    .addSubcommand(s => s.setName("buy").setDescription("Buy an item").addStringOption(o => o.setName("item").setDescription("Item name").setRequired(true).addChoices(
      {name:"Phone — $200",value:"Phone"},{name:"ID Card — $25",value:"ID Card"},{name:"Driving Licence — $50",value:"Driving Licence"},
      {name:"Lockpick — $15",value:"Lockpick"},{name:"Knife — $12",value:"Knife"},{name:"Tool Kit — $35",value:"Tool Kit"},
      {name:"Screwdriver — $10",value:"Screwdriver"},{name:"Flower Pot — $8",value:"Flower Pot"},{name:"Rag — $4",value:"Rag"},
      {name:"Rolling Papers — $3",value:"Rolling Papers"},{name:"Hammer — $18",value:"Hammer"},{name:"Baseball Bat — $25",value:"Baseball Bat"},
      {name:"Spray Can — $8",value:"Spray Can"},{name:"Flashlight — $15",value:"Flashlight"}
    ))),
  cmd("inventory", "View your inventory"),
  new SlashCommandBuilder().setName("job").setDescription("RP jobs")
    .addSubcommand(s => s.setName("menu").setDescription("View available jobs"))
    .addSubcommand(s => s.setName("take").setDescription("Take a job").addStringOption(o => o.setName("job").setDescription("Job").setRequired(true).addChoices(
      {name:"Trash Collector — postal 304",value:"Trash Collector"},{name:"Postal Worker — postal 308",value:"Postal Worker"},
      {name:"Gas Station Worker — postal 200",value:"Gas Station Worker"},{name:"Mechanic — postal 211",value:"Mechanic"}
    )))
    .addSubcommand(s => s.setName("finish").setDescription("Finish a job shift and earn RP money")),
  new SlashCommandBuilder().setName("psychotest").setDescription("Complete the RP firearm psychotest"),
  new SlashCommandBuilder().setName("gunshop").setDescription("Buy an RP firearm after eligibility check")
    .addStringOption(o => o.setName("item").setDescription("Firearm").setRequired(true).addChoices(
      {name:"Beretta M9 — $900",value:"Beretta M9"},{name:"Colt M1911 — $800",value:"Colt M1911"},{name:"Remington 700 — $2,500",value:"Remington 700"})),
  new SlashCommandBuilder().setName("blackmarket").setDescription("Illegal RP black market at postal 501")
    .addStringOption(o => o.setName("item").setDescription("Item").setRequired(true).addChoices(
      {name:"Tec-9 — $85,000",value:"Tec-9"},{name:"Scorpion — $100,000",value:"Scorpion"},{name:"Beretta M9 — $45,000",value:"Blackmarket Beretta M9"},
      {name:"M14 — $150,000",value:"M14"},{name:"Metanfetamin — $8,000",value:"Metanfetamin"},{name:"Blackdomina — $12,000",value:"Blackdomina"},
      {name:"Kokain — $6,000",value:"Kokain"},{name:"Marihuana — $2,500",value:"Marihuana"},{name:"Jelly Rancher — $4,000",value:"Jelly Rancher"},{name:"Lean — $5,000",value:"Lean"}
    )),
  new SlashCommandBuilder().setName("postal").setDescription("Look up ER:LC postal codes")
    .addStringOption(o => o.setName("code").setDescription("Postal code, e.g. 501").setRequired(true)),
  new SlashCommandBuilder().setName("locations").setDescription("Show known ER:LC postal locations"),
  new SlashCommandBuilder().setName("roll-dice").setDescription("Roll a dice")
    .addIntegerOption(o => o.setName("sides").setDescription("Number of sides").setMinValue(2).setMaxValue(100).setRequired(false)),
  new SlashCommandBuilder().setName("yes-no").setDescription("Ask a yes/no question")
    .addStringOption(o => o.setName("question").setDescription("Your question").setRequired(true)),
  new SlashCommandBuilder().setName("call").setDescription("Send an RP service call")
    .addStringOption(o => o.setName("service").setDescription("Service needed").setRequired(true).addChoices(
      {name:"Police",value:"Police"},{name:"Fire Department",value:"Fire Department"},{name:"EMS",value:"EMS"},{name:"Mechanic",value:"Mechanic"}))
    .addStringOption(o => o.setName("location").setDescription("Postal code or location").setRequired(true))
    .addStringOption(o => o.setName("details").setDescription("What happened").setRequired(true)),
  new SlashCommandBuilder().setName("mdt").setDescription("RP MDT record lookup")
    .addSubcommand(s => s.setName("person").setDescription("Find a citizen record").addStringOption(o => o.setName("name").setDescription("Channel name").setRequired(true)))
    .addSubcommand(s => s.setName("vehicle").setDescription("Vehicle lookup").addStringOption(o => o.setName("plate").setDescription("Plate").setRequired(true))),
  new SlashCommandBuilder().setName("manage-job").setDescription("Staff: manage a member's job")
    .addUserOption(o => o.setName("member").setDescription("Member").setRequired(true))
    .addStringOption(o => o.setName("job").setDescription("Job title").setRequired(true)),
  new SlashCommandBuilder().setName("issue-invoice").setDescription("Staff: issue a fictional RP invoice")
    .addUserOption(o => o.setName("member").setDescription("Member").setRequired(true))
    .addIntegerOption(o => o.setName("amount").setDescription("Amount").setMinValue(1).setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true)),
  new SlashCommandBuilder().setName("item-give").setDescription("Staff: give an inventory item")
    .addUserOption(o => o.setName("member").setDescription("Member").setRequired(true))
    .addStringOption(o => o.setName("item").setDescription("Item").setRequired(true))
    .addIntegerOption(o => o.setName("amount").setDescription("Quantity").setMinValue(1).setMaxValue(99).setRequired(false)),
  new SlashCommandBuilder().setName("ticket").setDescription("Open a private support ticket")
    .addStringOption(o => o.setName("reason").setDescription("What do you need help with?").setRequired(true))
];
const commandJSON = commands.map(c => c.toJSON());

async function addCitizenRecord(interaction, sub, section) {
  if (!await requireStaff(interaction)) return;
  const guild = await client.guilds.fetch(process.env.DATABASE_GUILD_ID);
  const channelName = slug(interaction.options.getString("name", true));
  const channel = guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.name === channelName);
  if (!channel) return interaction.reply({content:`Citizen channel "${channelName}" was not found in the database server.`,ephemeral:true});
  const details = interaction.options.getString("details", true).trim();
  const messages = await channel.messages.fetch({limit:20});
  const root = messages.find(m => m.author.id === client.user.id && m.embeds[0]?.title === "SAN DIEGO CITIZEN DATABASE");
  if (!root) return interaction.reply({content:"Citizen card not found in that channel.",ephemeral:true});
  const embed = EmbedBuilder.from(root.embeds[0]);
  const field = embed.data.fields?.find(f => f.name === section);
  const entry = `• ${new Date().toISOString().slice(0,10)} — ${details}`;
  if (field) field.value = field.value === "No records." ? entry : `${field.value}\n${entry}`.slice(0,1024);
  else embed.addFields({name:section,value:entry});
  embed.setTimestamp();
  await root.edit({embeds:[embed]});
  await interaction.reply({content:`Added ${section} record to ${channel.name}.`,ephemeral:true});
}
const locations = {
  "501":"Chop Shop / Vine Street", "304":"Waste Center (garbage collection)", "308":"Post Office",
  "200":"Gas-N-Go", "203":"Car Dealership", "211":"Auto Repairs & Mods", "401":"Gun Store",
  "602":"County Gas Station", "1110":"Springfield Gas-N-Go"
};
const shopPrices = {
  "Phone":200,"ID Card":25,"Driving Licence":50,"Lockpick":15,"Knife":12,"Tool Kit":35,
  "Screwdriver":10,"Flower Pot":8,"Rag":4,"Rolling Papers":3,"Hammer":18,"Baseball Bat":25,
  "Spray Can":8,"Flashlight":15
};
const blackPrices = {"Tec-9":85000,"Scorpion":100000,"Blackmarket Beretta M9":45000,"M14":150000,
  "Metanfetamin":8000,"Blackdomina":12000,"Kokain":6000,"Marihuana":2500,"Jelly Rancher":4000,"Lean":5000};
const gunPrices = {"Beretta M9":900,"Colt M1911":800,"Remington 700":2500};

client.once("ready", () => console.log(`San Diego Roleplay logged in as ${client.user.tag}`));
client.on("interactionCreate", async i => {
  try {
    if (i.isChatInputCommand()) {
      const u = userData(i.user.id);
      if (i.commandName === "id") {
        const sub = i.options.getSubcommand();
        if (sub === "create") {
          const modal = new ModalBuilder().setCustomId("id-create-modal").setTitle("Create Citizen ID");
          const first = new TextInputBuilder().setCustomId("first").setLabel("First Name").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50);
          const last = new TextInputBuilder().setCustomId("last").setLabel("Last Name").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50);
          const dob = new TextInputBuilder().setCustomId("dob").setLabel("Date of Birth (YYYY-MM-DD)").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(10).setPlaceholder("2000-05-21");
          const gender = new TextInputBuilder().setCustomId("gender").setLabel("Gender").setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(20).setPlaceholder("Male / Female / Other");
          modal.addComponents(new ActionRowBuilder().addComponents(first),new ActionRowBuilder().addComponents(last),new ActionRowBuilder().addComponents(dob),new ActionRowBuilder().addComponents(gender));
          return i.showModal(modal);
        }
        if (sub === "view") {
          if (!await requireStaff(i)) return;
          const guild = await client.guilds.fetch(process.env.DATABASE_GUILD_ID);
          const name = slug(i.options.getString("name",true));
          const ch = guild.channels.cache.find(c=>c.type===ChannelType.GuildText&&c.name===name);
          return i.reply({content:ch?`Citizen record: ${ch}`:`No record found for ${name}.`,ephemeral:true});
        }
        const sections = {citation:"CITATIONS",registration:"REGISTRATION",jail:"JAIL RECORD",warrant:"WARRANT"};
        return addCitizenRecord(i,sub,sections[sub]);
      }
      if (i.commandName === "balance") return i.reply({content:`Cash: **${money(u.cash)}**\nBank: **${money(u.bank)}**`,ephemeral:true});
      if (i.commandName === "daily") {
        if (Date.now()-u.dailyAt < 86400000) return i.reply({content:"You have already claimed your daily reward. Try again later.",ephemeral:true});
        u.cash += 250; u.dailyAt=Date.now(); saveData(data);
        return i.reply({content:`Daily reward claimed: **$250**. Cash: ${money(u.cash)}`,ephemeral:true});
      }
      if (i.commandName === "transfer") {
        const target=i.options.getUser("member",true), amount=i.options.getInteger("amount",true);
        if(target.bot||target.id===i.user.id) return i.reply({content:"Choose another human member.",ephemeral:true});
        if(u.cash<amount) return i.reply({content:"You do not have enough cash.",ephemeral:true});
        const t=userData(target.id); u.cash-=amount; t.cash+=amount; saveData(data);
        return i.reply({content:`Transferred ${money(amount)} to ${target}.`,ephemeral:true});
      }
      if (i.commandName === "bank") {
        const amount=i.options.getInteger("amount",true);
        if(i.options.getSubcommand()==="deposit"){if(u.cash<amount)return i.reply({content:"Not enough cash.",ephemeral:true});u.cash-=amount;u.bank+=amount;}
        else {if(u.bank<amount)return i.reply({content:"Not enough in bank.",ephemeral:true});u.bank-=amount;u.cash+=amount;}
        saveData(data); return i.reply({content:`Done. Cash: ${money(u.cash)} • Bank: ${money(u.bank)}`,ephemeral:true});
      }
      if (i.commandName === "shop") {
        if(i.options.getSubcommand()==="list") return i.reply({content:Object.entries(shopPrices).map(([k,v])=>`**${k}** — ${money(v)}`).join("\n"),ephemeral:true});
        const item=i.options.getString("item",true), price=shopPrices[item];
        if(u.cash<price)return i.reply({content:`You need ${money(price)}.`,ephemeral:true});
        u.cash-=price;u.inventory[item]=(u.inventory[item]||0)+1;saveData(data);
        return i.reply({content:`Purchased **${item}** for ${money(price)}.`,ephemeral:true});
      }
      if (i.commandName === "inventory") return i.reply({content:Object.keys(u.inventory).length?Object.entries(u.inventory).map(([k,v])=>`**${k}** × ${v}`).join("\n"):"Your inventory is empty.",ephemeral:true});
      if (i.commandName === "job") {
        const sub=i.options.getSubcommand();
        if(sub==="menu") return i.reply({content:"**Available RP jobs**\n• Trash Collector — postal 304\n• Postal Worker — postal 308\n• Gas Station Worker — postal 200\n• Mechanic — postal 211",ephemeral:true});
        if(sub==="take"){u.job=i.options.getString("job",true);saveData(data);return i.reply({content:`You took the job: **${u.job}**. Use /job finish after roleplaying the shift.`,ephemeral:true});}
        if(!u.job)return i.reply({content:"You do not have a job. Use /job take first.",ephemeral:true});
        const reward=150+Math.floor(Math.random()*151);u.cash+=reward;saveData(data);
        return i.reply({content:`Shift completed as **${u.job}**. You earned ${money(reward)}.`,ephemeral:true});
      }
      if (i.commandName === "psychotest") {u.psychotest=true;saveData(data);return i.reply({content:"RP psychotest marked as completed. Staff should verify this in roleplay.",ephemeral:true});}
      if (i.commandName === "gunshop") {
        const item=i.options.getString("item",true),price=gunPrices[item];
        if(!u.psychotest||!u.firearmLicense)return i.reply({content:"Access denied: complete /psychotest and have a valid RP firearm license recorded by staff.",ephemeral:true});
        if(u.cash<price)return i.reply({content:`You need ${money(price)}.`,ephemeral:true});
        u.cash-=price;u.inventory[item]=(u.inventory[item]||0)+1;saveData(data);
        return i.reply({content:`Purchased **${item}** for ${money(price)}. This is an RP inventory item only.`,ephemeral:true});
      }
      if (i.commandName === "blackmarket") {
        const item=i.options.getString("item",true),price=blackPrices[item];
        if(u.cash<price)return i.reply({content:`You need ${money(price)}.`,ephemeral:true});
        u.cash-=price;u.inventory[item]=(u.inventory[item]||0)+1;saveData(data);
        return i.reply({content:`Purchased RP item **${item}** for ${money(price)}. Black market postal: **501**.`,ephemeral:true});
      }
      if (i.commandName === "postal") {
        const code=i.options.getString("code",true);
        return i.reply({content:locations[code]?`**Postal ${code}:** ${locations[code]}`:"Unknown postal code in this bot's list.",ephemeral:true});
      }
      if (i.commandName === "locations") return i.reply({content:Object.entries(locations).map(([k,v])=>`**${k}** — ${v}`).join("\n"),ephemeral:true});
      if (i.commandName === "roll-dice") {const sides=i.options.getInteger("sides")||6;return i.reply(`${i.user} rolled **${1+Math.floor(Math.random()*sides)}** (d${sides}).`);}
      if (i.commandName === "yes-no") {const q=i.options.getString("question",true);return i.reply(`**Question:** ${q}\n**Answer:** ${["Yes","No","Probably","Probably not","Ask again later"][Math.floor(Math.random()*5)]}`);}
      if (i.commandName === "call") {
        const service=i.options.getString("service",true),loc=i.options.getString("location",true),details=i.options.getString("details",true);
        return i.reply({content:`RP call created.\n**Service:** ${service}\n**Location:** ${loc}\n**Details:** ${details}\nStaff can route this call in roleplay.`,ephemeral:false});
      }
      if (i.commandName === "mdt") {
        if(!await requireStaff(i))return;
        if(i.options.getSubcommand()==="person"){
          const g=await client.guilds.fetch(process.env.DATABASE_GUILD_ID),n=slug(i.options.getString("name",true));
          const ch=g.channels.cache.find(c=>c.type===ChannelType.GuildText&&c.name===n);
          return i.reply({content:ch?`MDT result: ${ch}`:`No citizen record found for ${n}.`,ephemeral:true});
        }
        return i.reply({content:"Vehicle MDT lookup is a placeholder until vehicle registration records are connected.",ephemeral:true});
      }
      if (i.commandName === "manage-job") {
        if(!await requireStaff(i))return;
        const target=i.options.getUser("member",true),job=i.options.getString("job",true);
        userData(target.id).job=job;saveData(data);
        return i.reply({content:`Assigned **${job}** to ${target}.`,ephemeral:true});
      }
      if (i.commandName === "issue-invoice") {
        if(!await requireStaff(i))return;
        const target=i.options.getUser("member",true),amount=i.options.getInteger("amount",true),reason=i.options.getString("reason",true);
        const tu=userData(target.id);tu.cash-=amount;saveData(data);
        return i.reply({content:`Invoice issued to ${target}: ${money(amount)} — ${reason}.`,ephemeral:true});
      }
      if (i.commandName === "item-give") {
        if(!await requireStaff(i))return;
        const target=i.options.getUser("member",true),item=i.options.getString("item",true),amount=i.options.getInteger("amount")||1;
        const tu=userData(target.id);tu.inventory[item]=(tu.inventory[item]||0)+amount;saveData(data);
        return i.reply({content:`Gave ${target} ${amount} × **${item}**.`,ephemeral:true});
      }
      if (i.commandName === "ticket") {
        const reason=i.options.getString("reason",true);
        const channel=await i.guild.channels.create({
          name:`ticket-${slug(i.user.username)}`.slice(0,90),type:ChannelType.GuildText,
          permissionOverwrites:[
            {id:i.guild.roles.everyone.id,deny:[PermissionsBitField.Flags.ViewChannel]},
            {id:i.user.id,allow:[PermissionsBitField.Flags.ViewChannel,PermissionsBitField.Flags.SendMessages,PermissionsBitField.Flags.ReadMessageHistory]},
            {id:client.user.id,allow:[PermissionsBitField.Flags.ViewChannel,PermissionsBitField.Flags.SendMessages,PermissionsBitField.Flags.ReadMessageHistory]},
            ...(staffRoleIds.map(id=>({id,allow:[PermissionsBitField.Flags.ViewChannel,PermissionsBitField.Flags.SendMessages,PermissionsBitField.Flags.ReadMessageHistory]})))
          ]
        });
        await channel.send({content:`${i.user} opened a ticket.\n**Reason:** ${reason}`});
        return i.reply({content:`Your private ticket has been created: ${channel}`,ephemeral:true});
      }
    }
    if (i.isModalSubmit() && i.customId === "id-create-modal") {
      const first=i.fields.getTextInputValue("first").trim(),last=i.fields.getTextInputValue("last").trim();
      const dob=i.fields.getTextInputValue("dob").trim(),gender=i.fields.getTextInputValue("gender").trim();
      if(!/^\d{4}-\d{2}-\d{2}$/.test(dob))return i.reply({content:"Use date format YYYY-MM-DD, e.g. 2000-05-21.",ephemeral:true});
      const guild=await client.guilds.fetch(process.env.DATABASE_GUILD_ID);
      const category=await getCategory(guild,categoryKey(last));
      const channelName=slug(`${first}-${last}`);
      const existing=guild.channels.cache.find(c=>c.type===ChannelType.GuildText&&c.name===channelName);
      if(existing)return i.reply({content:`A record already exists: ${existing}. Ask staff to check the database.`,ephemeral:true});
      const citizenId=`SD-${Date.now().toString().slice(-7)}`;
      const ch=await guild.channels.create({
        name:channelName,type:ChannelType.GuildText,parent:category.id,topic:`Citizen record • ${first} ${last} • ${citizenId}`,
        permissionOverwrites:[
          {id:guild.roles.everyone.id,deny:[PermissionsBitField.Flags.ViewChannel]},
          {id:client.user.id,allow:[PermissionsBitField.Flags.ViewChannel,PermissionsBitField.Flags.SendMessages,PermissionsBitField.Flags.EmbedLinks,PermissionsBitField.Flags.ReadMessageHistory,PermissionsBitField.Flags.ManageChannels]}
        ]
      });
      await ch.send({embeds:[citizenEmbed(first,last,dob,gender,citizenId)]});
      return i.reply({content:`Citizen ID created!\n**Citizen ID:** ${citizenId}\n**Database record:** ${ch.name}\nYour record is stored in San Diego Citizen Database.`,ephemeral:true});
    }
  } catch(e) {
    console.error(e);
    const msg="An error occurred. Check bot logs, server IDs, and bot permissions.";
    if(i.isRepliable()) {
      if(i.replied||i.deferred) await i.followUp({content:msg,ephemeral:true}).catch(()=>{});
      else await i.reply({content:msg,ephemeral:true}).catch(()=>{});
    }
  }
});
client.login(process.env.DISCORD_TOKEN);
